## ---- echo = FALSE, message = FALSE, warning = FALSE---------------------
library(CohortMethod)
knitr::opts_chunk$set(
  cache=FALSE,
  comment = "#>",
  error = FALSE,
  tidy = FALSE)

## ----eval=FALSE----------------------------------------------------------
#  library(TofaRep)
#  ?execute

## ----eval=FALSE----------------------------------------------------------
#  # Insert cohort definitions from ATLAS into package -----------------------
#  OhdsiRTools::insertCohortDefinitionSetInPackage(fileName = "CohortsToCreate.csv",
#                                                  baseUrl = Sys.getenv("baseUrl"),
#                                                  insertTableSql = TRUE,
#                                                  insertCohortCreationR = TRUE,
#                                                  generateStats = FALSE,
#                                                  packageName = "TofaRep")

## ----eval=FALSE----------------------------------------------------------
#  source("extras/CreateStudyAnalysisDetails.R")
#  createAnalysesDetails("inst/settings/")

